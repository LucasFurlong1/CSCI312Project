﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSCI312HuffmanEncodingLucasFurlong
{
    public class SortedLinkedList<T> : LinkedList<T> where T : IComparable
    {
        public void Add(T element)
        {

            if (Count == 0)
            {
                AddFirst(element);
            }
            else if (First.Value.CompareTo(element) >= 0)
            {
                AddBefore(First, element);
            }
            else if (Last.Value.CompareTo(element) <= 0)
            {
                AddAfter(Last, element);
            }
            else if (First.Value.CompareTo(element) < 0 && Last.Value.CompareTo(element) > 0)
            {
                LinkedListNode<T> pointer = First;

                while (pointer != null)
                {
                    if (pointer.Value.CompareTo(element) > 0 || pointer.Value.CompareTo(element) == 0)
                    {
                        AddBefore(pointer, element);
                        break;
                    }
                    pointer = pointer.Next;
                }
            }
        }
    }
}
