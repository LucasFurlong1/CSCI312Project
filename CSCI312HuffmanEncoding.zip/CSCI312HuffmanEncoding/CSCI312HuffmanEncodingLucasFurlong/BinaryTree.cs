﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Linq;
using System.IO;


namespace CSCI312HuffmanEncodingLucasFurlong
{
    public class BinaryTree<T> : IComparable where T : IComparable
    {
        #region Fields
        private int c;
        private BinaryTreeNode<T> root;
        private BinaryTreeNode<T> current;
        private List<Tuple<T, string>> codes;

        public enum Relative : int
        {
            leftChild, rightChild, parent, root
        };
        #endregion
        #region Constructors
        public BinaryTree()
        {
            c = 0;
            root = null;
            current = null;
        }
        public BinaryTree(BinaryTreeNode<T> r)
        {
            root = r;
            current = null;
            c = 0;
        }
        public BinaryTree(T node)
        {
            root = new BinaryTreeNode<T>(node);
            current = null;
            c = 0;
        }
        #endregion
        #region Properties
        public BinaryTreeNode<T> Current
        {
            get
            { return current; }
            set
            { current = value; }
        }
        public int Count
        {
            get { return c; }
            set { c = value; }
        }
        public BinaryTreeNode<T> Root
        {
            get { return root; }
            set { root = value; }
        }
        #endregion
        #region Methods
        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return -1;
            }
            if (!(obj is BinaryTree<T>))
            {
                throw new ArgumentException("object must be BinaryTree object instance");
            }

            BinaryTree<T> bt = obj as BinaryTree<T>;

            return this.Root.Value.CompareTo(bt.Root.Value);
        }

        public Boolean Insert(BinaryTreeNode<T> node, Relative rel)
        {
            Boolean inserted = true;

            if ((rel == Relative.leftChild && current.Left != null)
                    || (rel == Relative.rightChild && current.Right != null))
            {
                inserted = false;
            }
            else
            {
                switch (rel)
                {
                    case Relative.leftChild:
                        current.Left = node;
                        break;
                    case Relative.rightChild:
                        current.Right = node;
                        break;
                    case Relative.root:
                        if (root == null)
                        {
                            root = node;
                        }
                        current = root;
                        break;
                }
                c++;
            }

            return inserted;
        }
        public Boolean Insert(T data, Relative rel)
        {
            Boolean inserted = true;

            BinaryTreeNode<T> node = new BinaryTreeNode<T>(data);

            if ((rel == Relative.leftChild && current.Left != null)
                    || (rel == Relative.rightChild && current.Right != null))
            {
                inserted = false;
            }
            else
            {
                switch (rel)
                {
                    case Relative.leftChild:
                        current.Left = node;
                        break;
                    case Relative.rightChild:
                        current.Right = node;
                        break;
                    case Relative.root:
                        if (root == null)
                        {
                            root = node;
                        }
                        current = root;
                        break;
                }
                c++;
            }

            return inserted;
        }
        public void BuildTable(string c, BinaryTreeNode<T> node)
        {
            if (node == null)
            {
                return;
            }
            if (node.isLeaf())
            {
                Console.WriteLine(node.Value.ToString());
                Console.WriteLine(c);
                node.Coding = c;
                codes.Add(new Tuple<T, string>(node.Value, c));
                return;
            }
            BuildTable(c + "1", node.Left);
            BuildTable(c + "0", node.Right);
        }
        public void InOrderList(BinaryTreeNode<T> data)
        {
            if (data != null)
            {
                InOrderList(data.Left);
                Console.WriteLine(data.Value.ToString());
                InOrderList(data.Right);
            }
        }
        public List<Tuple<T, string>> getCodes(BinaryTree<T> node)
        {
            codes = new List<Tuple<T, string>>();
            BuildTable("", node.Root);
            return codes;
        }
        #endregion
    }
}
