﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSCI312HuffmanEncodingLucasFurlong
{
    class Encoding
    {
        #region Fields
        private char c;
        private string code;
        #endregion
        #region Constructors
        public Encoding()
        {
            c = '\0';
            code = string.Empty;
        }
        public Encoding(char ch, string encoding)
        {
            c = ch;

            if (encoding == null)
                throw new ArgumentNullException("The encoding argument cannot be null!");

            code = encoding;
        }
        #endregion
        #region Properties
        public char Character
        {
            get { return c; }
            set { c = value; }
        }
        public string Code
        {
            get { return code; }
            set { code = value; }
        }
        #endregion
        #region Methods
        public override string ToString()
        {
            return String.Format($"Character = {c} ASCII = {(int)c} Encoding = '{code}'");
        }

        public override int GetHashCode()
        {
            return (int)c;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }


            if (obj == this)
            {
                return true;
            }


            if (!(obj is Encoding))
            {
                return false;
            }

            CharacterFrequency rhs = (CharacterFrequency)obj;

            return this.Character == rhs.Character;
        }
        #endregion
    }
}
