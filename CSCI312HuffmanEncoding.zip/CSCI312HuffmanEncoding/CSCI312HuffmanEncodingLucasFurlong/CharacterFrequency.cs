﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSCI312HuffmanEncodingLucasFurlong
{
    class CharacterFrequency : IComparable
    {
        #region Fields
        private char _ch;
        private int _freq;
        #endregion
        #region Constructors
        public CharacterFrequency()
        {
            _ch = '\0';
            _freq = 0;
        }
        public CharacterFrequency(char ch)
        {
            _ch = ch;
            _freq = 0;
        }
        public CharacterFrequency(char ch, int fr)
        {
            _ch = ch;
            _freq = fr;
        }
        #endregion
        #region Properties
        public int Frequency
        {
            get { return _freq; }
            set { if (value >= 0) _freq = value; }
        }

        public char Character
        {
            get { return _ch; }
            set { _ch = value; }
        }
        #endregion
        #region Methods
        public void Increment()
        {
            _freq++;
        }
        public override int GetHashCode()
        {
            return (int)_ch;

        }
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            if (this == obj)
                return true;

            if (!(obj is CharacterFrequency))
                return false;


            CharacterFrequency cf = obj as CharacterFrequency;

            return this.Character.Equals(cf.Character);
        }
        public override string ToString()
        {
            return $"Character = {_ch} ASCII = {(int)_ch} Count = {_freq}";
        }
        public int CompareTo(object obj)
        {
            if(obj == null)
            {
                return -1;
            }

            if(!(obj is CharacterFrequency))
            {
                throw new ArgumentException("object must be CharacterFrequency object instance");
            }

            CharacterFrequency cf = obj as CharacterFrequency;

            return this.Frequency.CompareTo(cf.Frequency);
        }
        #endregion
    }
}
