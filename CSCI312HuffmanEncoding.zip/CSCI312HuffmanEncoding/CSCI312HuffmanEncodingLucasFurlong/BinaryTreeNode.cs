﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSCI312HuffmanEncodingLucasFurlong
{
    public class BinaryTreeNode<T> where T : IComparable
    {
        #region Fields
        private T v;
        private BinaryTreeNode<T> left, right;
        private string coding;
        #endregion
        #region Constructors
        public BinaryTreeNode()
        {
            v = default(T);
            left = null;
            right = null;
            coding = string.Empty;
        }
        public BinaryTreeNode(T element)
        {
            v = element;
            left = null;
            right = null;
            coding = string.Empty;
        }
        #endregion
        #region Properties
        public T Value
        {
            get { return v; }
            set { v = value; }
        }
        public BinaryTreeNode<T> Left
        {
            get { return left; }
            set { left = value; }
        }
        public BinaryTreeNode<T> Right
        {
            get { return right; }
            set { right = value; }
        }
        public string Coding
        {
            get { return coding; }
            set { coding = value; }
        }
        #endregion
        #region Methods
        public Boolean isLeaf()
        {
            return (left == null && right == null);
        }
        #endregion
    }
}
