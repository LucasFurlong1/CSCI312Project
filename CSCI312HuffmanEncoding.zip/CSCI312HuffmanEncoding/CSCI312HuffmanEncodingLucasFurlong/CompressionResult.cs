﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;

namespace CSCI312HuffmanEncodingLucasFurlong
{
    class CompressionResult
    {
        #region Fields
        private long _original_file_size;
        private long _compressed_file_size;
        #endregion
        #region Constructors
        public CompressionResult(string inputFileName, string outputFileName)
        {
            FileInfo o = new FileInfo(inputFileName);
            FileInfo c = new FileInfo(outputFileName);
            // TODO: Use System.IO.FileInfo to get file sizes
            _original_file_size = o.Length;
            _compressed_file_size = c.Length;
        }
        #endregion
        #region Properties
        public long UncompressedSize
        {
            get { return _original_file_size; }
        }
        public long CompressedSize
        {
            get { return _compressed_file_size; }
        }
        #endregion
        #region Methods
        public override string ToString()
        {
            return $"Old size: {_original_file_size}; New Size: {_compressed_file_size}";
        }
        #endregion
    }
}
