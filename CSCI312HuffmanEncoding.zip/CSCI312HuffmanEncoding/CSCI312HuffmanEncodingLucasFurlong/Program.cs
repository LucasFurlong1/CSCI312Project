﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections;

namespace CSCI312HuffmanEncodingLucasFurlong
{

    class Program
    {

        #region Constants
        const int PROGRAM_MODE = 0;
        const int INPUT_FILENAME = 1;
        const int OUTPUT_FILENAME = 2;
        const int TABLE_FILENAME = 3;
        //change program mode here or in command line arguments
        enum Mode { C, D }
        static Mode m = Mode.C;
        #endregion
        #region Bit Methods
        static byte TurnBitOn(byte value, int position)
        {
            return (byte)(value | (int)Math.Pow(2, position));
        }
        static bool IsBitOn(byte value, int position)
        {
            var b = (byte)(value & (int)Math.Pow(2, position));
            return b != 0;
        }
        static byte TurnBitOff(byte value, int position)
        {
            //todo? maybe
            return 0;
        }
        #endregion
        #region Compression Methods
        static CharacterFrequency[] CountCharacters(string inputfile)
        {
            CharacterFrequency[] aArray = new CharacterFrequency[256];


            for (int i = 0; i < 256; i++)
            {
                aArray[i] = new CharacterFrequency((char)i);
            }
            using (FileStream fileStream = File.Open(inputfile, FileMode.Open))
            {

                while (fileStream.Position != fileStream.Length)
                {
                    int v = fileStream.ReadByte();
                    if (v != -1)
                    {
                        aArray[v].Increment();
                    }

                }
                fileStream.Close();
            }
            return aArray;
        }
        static SortedLinkedList<BinaryTree<CharacterFrequency>> BuildOrderedList(CharacterFrequency[] characters)
        {
            SortedLinkedList<BinaryTree<CharacterFrequency>> list = new SortedLinkedList<BinaryTree<CharacterFrequency>>();
            foreach (CharacterFrequency element in characters)
            {
                if (element.Frequency != 0)
                {
                    BinaryTree<CharacterFrequency> node = new BinaryTree<CharacterFrequency>();
                    node.Insert(element, BinaryTree<CharacterFrequency>.Relative.root);
                    list.Add(node);
                }
            }


            return list;
        }
        static BinaryTree<CharacterFrequency> BuildTree(SortedLinkedList<BinaryTree<CharacterFrequency>> list)
        {

            while (list.Count > 1)
            {
                BinaryTree<CharacterFrequency> nodeOne = null;
                BinaryTree<CharacterFrequency> nodeTwo = null;
                nodeOne = list.First();
                list.RemoveFirst();
                nodeTwo = list.First();
                list.RemoveFirst();
                int pTotal = nodeOne.Current.Value.Frequency + nodeTwo.Current.Value.Frequency;
                BinaryTree<CharacterFrequency> tree = new BinaryTree<CharacterFrequency>();
                CharacterFrequency cf = new CharacterFrequency('\0', pTotal);
                tree.Insert(cf, BinaryTree<CharacterFrequency>.Relative.root);
                tree.Insert(nodeOne.Root, BinaryTree<CharacterFrequency>.Relative.leftChild);
                tree.Insert(nodeTwo.Root, BinaryTree<CharacterFrequency>.Relative.rightChild);
                list.Add(tree);
            }
            BinaryTree<CharacterFrequency> finalTree = null;
            finalTree = list.First();
            finalTree.InOrderList(finalTree.Root);
            return finalTree;
        }
        static List<Tuple<CharacterFrequency, string>> MakeTable(BinaryTree<CharacterFrequency> tree, string table)
        {
            var finalList = tree.getCodes(tree);
            using (FileStream fileWrite = File.Create(table))
            {
                for (int i = 24; i >= 0; i -= 8)
                {
                    fileWrite.WriteByte((byte)(tree.Root.Value.Frequency >> i));
                }
                foreach (var element in finalList)
                {
                    fileWrite.WriteByte((byte)element.Item1.Character);
                    fileWrite.WriteByte((byte)element.Item2.Length);
                    foreach (var character in element.Item2)
                    {
                        fileWrite.WriteByte((byte)character);
                    }
                }
            }
            return finalList;
        }
        static CompressionResult Compress(List<Tuple<CharacterFrequency, string>> codes, string inputFile, string outputFile)
        {
            using (FileStream fileRead = File.Open(inputFile, FileMode.Open))
            {
                using (FileStream fileWrite = File.Create(outputFile))
                {
                    string currentCode = "";
                    int bitPos = 7;
                    byte b = (byte)0;
                    int v = fileRead.ReadByte();
                    while (v != -1)
                    {
                        foreach (var element in codes)
                        {
                            if (element.Item1.Character == (char)v)
                            {
                                currentCode = element.Item2;
                            }
                        }

                        for (int i = 0; i < currentCode.Length; i++)
                        {
                            char c = currentCode[i];
                            if (bitPos == 0)
                            {
                                if (c == (char)49)
                                {
                                    b = TurnBitOn(b, bitPos);
                                }
                                fileWrite.WriteByte(b);
                                bitPos = 7;
                                b = (byte)0;
                            }
                            else
                            {
                                if (c == (char)49)
                                {
                                    b = TurnBitOn(b, bitPos);
                                }
                                bitPos--;
                            }
                        }
                        if (fileRead.Position == fileRead.Length)
                        {
                            fileWrite.WriteByte(b);
                        }
                        v = fileRead.ReadByte();
                    }
                }
            }
            return new CompressionResult(inputFile, outputFile);
        }
        #endregion
        #region Decompression Methods
        static BinaryTree<CharacterFrequency> BuildTreeFromFile(string tableFile)
        {
            BinaryTree<CharacterFrequency> tree;
            using (FileStream filereader = File.OpenRead(tableFile))
            {
                int v = filereader.ReadByte();
                int fileLength = 0;
                for (int i = 0; i < 4; i++)
                {
                    fileLength <<= 8;
                    fileLength |= v;
                    v = filereader.ReadByte();
                }

                BinaryTreeNode<CharacterFrequency> node = new BinaryTreeNode<CharacterFrequency>();
                BinaryTreeNode<CharacterFrequency> root = new BinaryTreeNode<CharacterFrequency>();
                root = node;
                while (v != -1)
                {
                    CharacterFrequency cf = new CharacterFrequency((char)v);

                    int codeLength = filereader.ReadByte();

                    for (int i = 0; i < codeLength; i++)
                    {
                        v = filereader.ReadByte();
                        if ((char)v == '1')
                        {
                            if (node.Left == null)
                            {
                                node.Left = new BinaryTreeNode<CharacterFrequency>();
                                node = node.Left;

                            }
                            else
                            {
                                node = node.Left;
                            }

                        }
                        else
                        {
                            if (node.Right == null)
                            {
                                node.Right = new BinaryTreeNode<CharacterFrequency>();
                                node = node.Right;

                            }
                            else
                            {
                                node = node.Right;
                            }
                        }

                    }
                    node.Value = cf;
                    v = filereader.ReadByte();
                    node = root;
                }
                root.Value = new CharacterFrequency('\0', fileLength);
                tree = new BinaryTree<CharacterFrequency>(node);
            }
            return tree;
        }
        static CompressionResult Decompress(BinaryTree<CharacterFrequency> tree, string inputFile, string outputFile)
        {
            using (FileStream fileRead = File.Open(inputFile, FileMode.Open))
            {
                using (FileStream fileWrite = File.Create(outputFile))
                {
                    int v = fileRead.ReadByte();

                    int charcounter = 0;
                    byte b = (byte)v;
                    int bitPos = 7;
                    int fileLength = tree.Root.Value.Frequency;
                    tree.Current = tree.Root;
                    while (v != -1)
                    {
                        while (bitPos >= 0)
                        {
                            if (charcounter < fileLength)
                            {
                                if (IsBitOn(b, bitPos) == true)
                                {
                                    tree.Current = tree.Current.Left;
                                    if (tree.Current.isLeaf())
                                    {
                                        fileWrite.WriteByte((byte)tree.Current.Value.Character);
                                        bitPos--;
                                        charcounter++;
                                        tree.Current = tree.Root;
                                    }
                                    else
                                    {
                                        bitPos--;
                                    }
                                }
                                else
                                {
                                    tree.Current = tree.Current.Right;
                                    if (tree.Current.isLeaf())
                                    {
                                        fileWrite.WriteByte((byte)tree.Current.Value.Character);
                                        bitPos--;
                                        charcounter++;
                                        tree.Current = tree.Root;
                                    }
                                    else
                                    {
                                        bitPos--;
                                    }
                                }
                            }
                            else if (charcounter == fileLength)
                            {
                                break;
                            }
                        }
                        v = fileRead.ReadByte();
                        b = (byte)v;
                        bitPos = 7;
                    }
                }
            }
            return new CompressionResult(inputFile, outputFile);
        }
        #endregion
        static void Main(string[] args)
        {
            #region Argument Checkers and Decompression Implementation
            if (args.Length != 4)
            {
                Console.WriteLine("Please pass in program mode (C for Compression and D for Decompression), input filename, custom output filename, and custom table name... EX: C read.txt write.txt table.txt");
                Console.WriteLine("Table filename must be saved to decompress file");
                Environment.Exit(0);
            } 
            if (!args[INPUT_FILENAME].EndsWith(".txt") || !args[OUTPUT_FILENAME].EndsWith(".txt") || !args[TABLE_FILENAME].EndsWith(".txt"))
            {
                Console.WriteLine("The input file, output file, and/or the table file must be a .txt file");
                Environment.Exit(0);
            }
            if (new FileInfo(args[INPUT_FILENAME]).Length == 0)
            {
                Console.WriteLine("Input file must contain data");
                Environment.Exit(0);
            }
            if (args[PROGRAM_MODE] != "C")
            {
                if (args[PROGRAM_MODE] == "D")
                {
                    var tree = BuildTreeFromFile(args[TABLE_FILENAME]);
                    var result = Decompress(tree, args[INPUT_FILENAME], args[OUTPUT_FILENAME]);
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Program mode must be C or D (C is Compression and D is Decompression");
                    Environment.Exit(0);
                }
            }
            #endregion
            #region Compression Implementation
            if ((Mode)Enum.Parse(typeof(Mode), args[PROGRAM_MODE]) == Mode.C)
            {
                var characterArray = CountCharacters(args[INPUT_FILENAME]);
                var characterList = BuildOrderedList(characterArray);
                var binaryTree = BuildTree(characterList);
                var encodingTable = MakeTable(binaryTree, args[TABLE_FILENAME]);
                var result = Compress(encodingTable, args[INPUT_FILENAME], args[OUTPUT_FILENAME]);
                Console.WriteLine(result);
            }
            #endregion
        }
    }
}
